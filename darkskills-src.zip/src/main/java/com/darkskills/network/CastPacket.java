package com.darkskills.network;

import com.darkskills.skill.SkillManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Client -> Server: player pressed a skill key. */
public record CastPacket(int slot) {
    public static void encode(CastPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.slot);
    }

    public static CastPacket decode(FriendlyByteBuf buf) {
        return new CastPacket(buf.readVarInt());
    }

    public static void handle(CastPacket m, CustomPayloadEvent.Context ctx) {
        ServerPlayer player = ctx.getSender();
        if (player != null) {
            SkillManager.cast(player, m.slot);
        }
    }
}
