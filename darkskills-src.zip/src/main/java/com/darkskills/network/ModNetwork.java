package com.darkskills.network;

import com.darkskills.DarkSkills;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.SimpleChannel;

public final class ModNetwork {
    public static final SimpleChannel CHANNEL = ChannelBuilder
            .named(ResourceLocation.fromNamespaceAndPath(DarkSkills.MODID, "main"))
            .networkProtocolVersion(1)
            .simpleChannel();

    private ModNetwork() {}

    public static void init() {
        CHANNEL.messageBuilder(CastPacket.class, NetworkDirection.PLAY_TO_SERVER)
                .encoder(CastPacket::encode)
                .decoder(CastPacket::decode)
                .consumerMainThread(CastPacket::handle)
                .add();

        CHANNEL.messageBuilder(SyncPacket.class, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncPacket::encode)
                .decoder(SyncPacket::decode)
                .consumerMainThread(SyncPacket::handle)
                .add();
    }
}
