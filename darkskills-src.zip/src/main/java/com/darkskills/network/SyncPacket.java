package com.darkskills.network;

import com.darkskills.client.ClientState;
import com.darkskills.skill.SkillManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server -> Client: darkness value + cooldowns for the HUD. */
public record SyncPacket(int darkness, int[] cdRemaining, int[] cdTotal) {
    public static void encode(SyncPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.darkness);
        for (int i = 0; i < SkillManager.SLOT_COUNT; i++) {
            buf.writeVarInt(m.cdRemaining[i]);
            buf.writeVarInt(m.cdTotal[i]);
        }
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        int darkness = buf.readVarInt();
        int[] rem = new int[SkillManager.SLOT_COUNT];
        int[] total = new int[SkillManager.SLOT_COUNT];
        for (int i = 0; i < SkillManager.SLOT_COUNT; i++) {
            rem[i] = buf.readVarInt();
            total[i] = buf.readVarInt();
        }
        return new SyncPacket(darkness, rem, total);
    }

    public static void handle(SyncPacket m, CustomPayloadEvent.Context ctx) {
        ClientState.apply(m.darkness, m.cdRemaining, m.cdTotal);
    }
}
