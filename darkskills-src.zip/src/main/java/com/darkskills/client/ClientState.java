package com.darkskills.client;

import com.darkskills.skill.SkillManager;

/** Plain data holder (no client-only imports, safe to load anywhere). */
public final class ClientState {
    public static int darkness;
    public static long tick;
    public static final long[] cdEnd = new long[SkillManager.SLOT_COUNT];
    public static final int[] cdTotal = new int[SkillManager.SLOT_COUNT];

    private ClientState() {}

    public static void apply(int d, int[] remaining, int[] total) {
        darkness = d;
        for (int i = 0; i < SkillManager.SLOT_COUNT; i++) {
            cdEnd[i] = tick + remaining[i];
            cdTotal[i] = total[i];
        }
    }

    public static int remaining(int slot) {
        return (int) Math.max(0, cdEnd[slot] - tick);
    }
}
