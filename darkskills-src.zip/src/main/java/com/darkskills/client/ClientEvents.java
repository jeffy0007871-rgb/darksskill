package com.darkskills.client;

import com.darkskills.DarkSkills;
import com.darkskills.network.CastPacket;
import com.darkskills.network.ModNetwork;
import com.darkskills.skill.Skill;
import com.darkskills.skill.SkillManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = DarkSkills.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        ClientState.tick++;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        for (int i = 0; i < Keys.SKILL.length; i++) {
            while (Keys.SKILL[i].consumeClick()) {
                if (mc.screen == null) {
                    ModNetwork.CHANNEL.send(new CastPacket(i), PacketDistributor.SERVER.noArg());
                }
            }
        }
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        GuiGraphics g = e.getGuiGraphics();
        Font font = mc.font;
        int w = g.guiWidth();
        int h = g.guiHeight();

        // --- Darkness bar (bottom right) ---
        int barW = 100, barH = 6;
        int bx = w - barW - 12;
        int by = h - 64;
        g.fill(bx - 1, by - 1, bx + barW + 1, by + barH + 1, 0xDD000000);
        g.fill(bx, by, bx + barW, by + barH, 0xFF1A0A24);
        int fill = barW * Math.min(ClientState.darkness, SkillManager.MAX_DARKNESS) / SkillManager.MAX_DARKNESS;
        g.fill(bx, by, bx + fill, by + barH, 0xFF8E24AA);
        g.drawString(font, "DARKNESS " + ClientState.darkness, bx, by - 10, 0xFFB388FF, true);

        // --- Skill slots ---
        int size = 22, gap = 4;
        int total = SkillManager.SLOT_COUNT * size + (SkillManager.SLOT_COUNT - 1) * gap;
        int sx = w - total - 12;
        int sy = h - 48;

        for (int i = 0; i < SkillManager.SLOT_COUNT; i++) {
            int x = sx + i * (size + gap);
            Skill skill = SkillManager.SLOTS[i];
            int rem = ClientState.remaining(i);
            boolean cooling = rem > 0;

            int border = skill == null ? 0xFF444444 : (cooling ? 0xFF666666 : 0xFFAB47BC);
            g.fill(x - 1, sy - 1, x + size + 1, sy + size + 1, border);
            g.fill(x, sy, x + size, sy + size, 0xEE120818);

            String icon = skill == null ? "?" : skill.icon();
            g.drawString(font, icon, x + (size - font.width(icon)) / 2, sy + 7,
                    skill == null ? 0xFF555555 : 0xFFE1BEE7, false);

            if (cooling && ClientState.cdTotal[i] > 0) {
                int oh = size * rem / ClientState.cdTotal[i];
                g.fill(x, sy, x + size, sy + oh, 0xBB000000);
                String t = String.format("%.1f", rem / 20f);
                g.drawString(font, t, x + (size - font.width(t)) / 2, sy + 7, 0xFFFFFFFF, true);
            }

            String key = Keys.SKILL[i].getTranslatedKeyMessage().getString();
            g.drawString(font, key, x + (size - font.width(key)) / 2, sy + size + 3, 0xFF9E9E9E, true);
        }
    }
}
