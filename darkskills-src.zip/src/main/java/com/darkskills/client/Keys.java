package com.darkskills.client;

import com.darkskills.skill.SkillManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public final class Keys {
    public static final KeyMapping[] SKILL = new KeyMapping[SkillManager.SLOT_COUNT];

    static {
        int[] codes = { InputConstants.KEY_Z, InputConstants.KEY_X, InputConstants.KEY_C, InputConstants.KEY_V };
        for (int i = 0; i < SKILL.length; i++) {
            SKILL[i] = new KeyMapping("key.darkskills.skill" + (i + 1),
                    InputConstants.Type.KEYSYM, codes[i], "key.categories.darkskills");
        }
    }

    private Keys() {}
}
