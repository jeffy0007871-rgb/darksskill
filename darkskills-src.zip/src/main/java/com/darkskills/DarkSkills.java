package com.darkskills;

import com.darkskills.network.ModNetwork;
import net.minecraftforge.fml.common.Mod;

@Mod(DarkSkills.MODID)
public class DarkSkills {
    public static final String MODID = "darkskills";

    public DarkSkills() {
        ModNetwork.init();
    }
}
