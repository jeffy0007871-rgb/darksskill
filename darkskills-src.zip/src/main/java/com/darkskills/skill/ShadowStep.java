package com.darkskills.skill;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Blink up to 10 blocks where you look, leaving a trail of smoke. */
public class ShadowStep implements Skill {
    private static final double RANGE = 10.0;

    @Override public String icon() { return "S"; }
    @Override public int cooldownTicks() { return 100; } // 5s
    @Override public int darknessGain() { return 15; }

    @Override
    public boolean cast(ServerPlayer p) {
        ServerLevel level = (ServerLevel) p.level();
        Vec3 look = p.getLookAngle();
        Vec3 start = p.getEyePosition();
        Vec3 end = start.add(look.scale(RANGE));

        var hit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 dest = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation().subtract(look.scale(0.6));
        dest = dest.subtract(0, p.getEyeHeight(), 0);

        Vec3 from = p.position();
        smoke(level, from);
        level.playSound(null, from.x, from.y, from.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 0.6f);

        p.teleportTo(dest.x, dest.y, dest.z);
        p.fallDistance = 0;

        smoke(level, dest);
        level.playSound(null, dest.x, dest.y, dest.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 0.8f);
        return true;
    }

    private static void smoke(ServerLevel level, Vec3 pos) {
        level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y + 1.0, pos.z, 30, 0.3, 0.6, 0.3, 0.02);
        level.sendParticles(ParticleTypes.PORTAL, pos.x, pos.y + 1.0, pos.z, 40, 0.4, 0.8, 0.4, 0.3);
    }
}
