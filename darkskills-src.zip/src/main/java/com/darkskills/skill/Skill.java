package com.darkskills.skill;

import net.minecraft.server.level.ServerPlayer;

public interface Skill {
    /** One letter shown on the HUD slot. */
    String icon();

    int cooldownTicks();

    /** How much Darkness this skill adds when cast. */
    int darknessGain();

    /** Run the skill on the server. Return false if it could not be cast (no cooldown/darkness then). */
    boolean cast(ServerPlayer player);
}
