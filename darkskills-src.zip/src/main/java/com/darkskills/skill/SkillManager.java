package com.darkskills.skill;

import com.darkskills.network.ModNetwork;
import com.darkskills.network.SyncPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class SkillManager {
    public static final int SLOT_COUNT = 4;
    public static final int MAX_DARKNESS = 100;
    private static final String KEY_DARKNESS = "ds_darkness";

    /** Slot 1-4 (Z X C V). null = locked / not built yet. */
    public static final Skill[] SLOTS = { new ShadowStep(), null, null, null };

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();

    private SkillManager() {}

    public static int getDarkness(ServerPlayer p) {
        return p.getPersistentData().getInt(KEY_DARKNESS);
    }

    private static void setDarkness(ServerPlayer p, int v) {
        p.getPersistentData().putInt(KEY_DARKNESS, Math.max(0, Math.min(MAX_DARKNESS, v)));
    }

    public static void cast(ServerPlayer p, int slot) {
        if (slot < 0 || slot >= SLOT_COUNT) return;
        Skill skill = SLOTS[slot];
        if (skill == null) {
            p.displayClientMessage(Component.literal("Skill locked"), true);
            return;
        }
        long now = p.level().getGameTime();
        long[] ready = READY_AT.computeIfAbsent(p.getUUID(), k -> new long[SLOT_COUNT]);
        if (now < ready[slot]) return;
        if (!skill.cast(p)) return;

        ready[slot] = now + skill.cooldownTicks();
        addDarkness(p, skill.darknessGain());
        sync(p);
    }

    public static void addDarkness(ServerPlayer p, int amount) {
        int d = getDarkness(p) + amount;
        if (d >= MAX_DARKNESS) {
            d = 0;
            startFrenzy(p);
        }
        setDarkness(p, d);
    }

    private static void startFrenzy(ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 1));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 1));
        p.displayClientMessage(Component.literal("\u00a75\u00a7lDARK FRENZY"), true);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(),
                SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 0.6f, 1.4f);
    }

    /** Called every tick for each server player. */
    public static void tick(ServerPlayer p) {
        if (p.tickCount % 20 != 0) return;
        int d = getDarkness(p);
        if (d > 0) {
            setDarkness(p, d - 1);
            sync(p);
        }
    }

    public static void sync(ServerPlayer p) {
        long now = p.level().getGameTime();
        long[] ready = READY_AT.getOrDefault(p.getUUID(), new long[SLOT_COUNT]);
        int[] rem = new int[SLOT_COUNT];
        int[] total = new int[SLOT_COUNT];
        for (int i = 0; i < SLOT_COUNT; i++) {
            rem[i] = (int) Math.max(0, ready[i] - now);
            total[i] = SLOTS[i] == null ? 0 : SLOTS[i].cooldownTicks();
        }
        ModNetwork.CHANNEL.send(new SyncPacket(getDarkness(p), rem, total), PacketDistributor.PLAYER.with(p));
    }

    public static void forget(UUID id) {
        READY_AT.remove(id);
    }
}
